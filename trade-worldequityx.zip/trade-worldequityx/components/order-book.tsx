"use client"

import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

// Sample data - replace with actual data in a real application
const buyOrders = [
  { price: 99.5, amount: 100 },
  { price: 99.0, amount: 200 },
  { price: 98.5, amount: 150 },
]

const sellOrders = [
  { price: 100.5, amount: 120 },
  { price: 101.0, amount: 180 },
  { price: 101.5, amount: 90 },
]

interface OrderBookProps {
  highlightSide?: 'buy' | 'sell'
}

export function OrderBook({ highlightSide }: OrderBookProps) {
  return (
    <div className="space-y-4 overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-1/3">Price</TableHead>
            <TableHead className="w-1/3">Amount</TableHead>
            <TableHead className="w-1/3">Total</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {sellOrders.reverse().map((order, index) => (
            <TableRow key={index} className={highlightSide === 'sell' ? 'bg-red-500/10' : ''}>
              <TableCell className="text-red-500">{order.price.toFixed(2)}</TableCell>
              <TableCell>{order.amount.toFixed(2)}</TableCell>
              <TableCell>{(order.price * order.amount).toFixed(2)}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <Table>
        <TableBody>
          {buyOrders.map((order, index) => (
            <TableRow key={index} className={highlightSide === 'buy' ? 'bg-green-500/10' : ''}>
              <TableCell className="text-green-500">{order.price.toFixed(2)}</TableCell>
              <TableCell>{order.amount.toFixed(2)}</TableCell>
              <TableCell>{(order.price * order.amount).toFixed(2)}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

