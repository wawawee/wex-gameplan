"use client"

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'

// Sample data - replace with actual data in a real application
const data = [
  { date: '2023-01-01', price: 100 },
  { date: '2023-02-01', price: 120 },
  { date: '2023-03-01', price: 110 },
  { date: '2023-04-01', price: 140 },
  { date: '2023-05-01', price: 130 },
  { date: '2023-06-01', price: 160 },
  { date: '2023-07-01', price: 180 },
]

export function TradingChart() {
  return (
    <ResponsiveContainer width="100%" height={300}>
      <LineChart data={data}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="date" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Line type="monotone" dataKey="price" stroke="#8884d8" activeDot={{ r: 8 }} />
      </LineChart>
    </ResponsiveContainer>
  )
}

