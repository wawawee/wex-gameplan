"use client"

import { useState } from 'react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { Button } from "@/components/ui/button"

// Sample data - replace with actual data in a real application
const generateData = (days: number) => {
  const data = []
  const startDate = new Date()
  startDate.setDate(startDate.getDate() - days)
  for (let i = 0; i <= days; i++) {
    const date = new Date(startDate)
    date.setDate(date.getDate() + i)
    data.push({
      date: date.toISOString().split('T')[0],
      price: Math.random() * 100 + 100
    })
  }
  return data
}

const timeframes = [
  { label: '1D', days: 1 },
  { label: '1W', days: 7 },
  { label: '1M', days: 30 },
  { label: '1Y', days: 365 },
]

export function TradingChart() {
  const [selectedTimeframe, setSelectedTimeframe] = useState(timeframes[2]) // Default to 1M
  const data = generateData(selectedTimeframe.days)

  return (
    <div className="w-full h-full flex flex-col">
      <div className="flex justify-end space-x-2 mb-4">
        {timeframes.map((tf) => (
          <Button
            key={tf.label}
            variant={tf === selectedTimeframe ? "default" : "outline"}
            size="sm"
            onClick={() => setSelectedTimeframe(tf)}
          >
            {tf.label}
          </Button>
        ))}
      </div>
      <ResponsiveContainer width="100%" height={300} minWidth={280}>
        <LineChart data={data} margin={{ top: 5, right: 5, left: 0, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis 
            dataKey="date" 
            tick={{ fontSize: 10 }}
            tickFormatter={(tick) => {
              const date = new Date(tick)
              return selectedTimeframe.days <= 7 
                ? date.toLocaleDateString(undefined, { weekday: 'short' })
                : date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })
            }}
            interval="preserveStartEnd"
          />
          <YAxis 
            tick={{ fontSize: 10 }}
            width={40}
            tickFormatter={(value) => `$${value.toFixed(0)}`}
          />
          <Tooltip 
            labelFormatter={(label) => new Date(label).toLocaleDateString()}
            formatter={(value) => [`$${value.toFixed(2)}`, 'Price']}
          />
          <Legend />
          <Line type="monotone" dataKey="price" stroke="#8884d8" activeDot={{ r: 8 }} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}

