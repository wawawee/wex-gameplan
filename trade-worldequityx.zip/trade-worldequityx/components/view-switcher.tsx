"use client"

import { Button } from "@/components/ui/button"

interface ViewSwitcherProps {
  currentView: 'desktop' | 'mobile';
  onViewChange: (view: 'desktop' | 'mobile') => void;
}

export function ViewSwitcher({ currentView, onViewChange }: ViewSwitcherProps) {
  return (
    <div className="fixed top-4 right-4 z-50 bg-background/80 backdrop-blur-sm rounded-lg shadow-lg p-2">
      <Button
        variant={currentView === 'desktop' ? 'default' : 'outline'}
        size="sm"
        onClick={() => onViewChange('desktop')}
        className="mr-2"
      >
        Desktop
      </Button>
      <Button
        variant={currentView === 'mobile' ? 'default' : 'outline'}
        size="sm"
        onClick={() => onViewChange('mobile')}
      >
        Mobile
      </Button>
    </div>
  )
}

