"use client"

import { useState, useEffect } from 'react'
import { Button } from "@/components/ui/button"
import dynamic from 'next/dynamic'

const DynamicWalletKit = dynamic(
  () => import('@reown/walletkit').then((mod) => mod.useWalletKit),
  { ssr: false }
)

export function ConnectButton() {
  const [mounted, setMounted] = useState(false)
  const walletKit = DynamicWalletKit()

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  const { connect, disconnect, isConnected, address } = walletKit

  if (isConnected && address) {
    return (
      <Button onClick={disconnect} variant="outline">
        Disconnect {address.slice(0, 6)}...{address.slice(-4)}
      </Button>
    )
  }

  return (
    <Button onClick={() => connect()}>
      Connect Wallet
    </Button>
  )
}

