"use client"

import { useState, useEffect } from 'react'
import { Button } from "@/components/ui/button"
import { useWalletKit } from '@reown/walletkit'

export function ConnectButton() {
  const [mounted, setMounted] = useState(false)
  const { connect, disconnect, isConnected, address } = useWalletKit()

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  if (isConnected && address) {
    return (
      <Button onClick={disconnect} variant="outline">
        Disconnect {address.slice(0, 6)}...{address.slice(-4)}
      </Button>
    )
  }

  return (
    <Button onClick={() => connect()}>
      Connect Wallet
    </Button>
  )
}

