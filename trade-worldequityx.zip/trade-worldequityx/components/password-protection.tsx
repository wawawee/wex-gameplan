"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

interface PasswordProtectionProps {
  onAuthenticate: (isAuthenticated: boolean) => void
}

export function PasswordProtection({ onAuthenticate }: PasswordProtectionProps) {
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    // In a real application, this would validate against a secure backend
    if (password === process.env.NEXT_PUBLIC_SITE_PASSWORD) {
      onAuthenticate(true)
      // Store authentication state
      sessionStorage.setItem('isAuthenticated', 'true')
    } else {
      setError("Incorrect password")
      onAuthenticate(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle>Password protected site</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <p className="text-sm text-muted-foreground">
                Please enter your password to get access.
              </p>
              <Input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Password"
                className="w-full"
              />
              {error && (
                <p className="text-sm text-destructive">{error}</p>
              )}
            </div>
            <Button type="submit" className="w-full bg-teal-600 hover:bg-teal-700">
              Submit
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}

