"use client"

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { TradingChart } from "@/components/trading-chart"
import { OrderBook } from "@/components/order-book"

export function TradingInterface() {
  const [amount, setAmount] = useState('')
  const [price, setPrice] = useState('')
  const [isMobile, setIsMobile] = useState(false)
  const [orderType, setOrderType] = useState<'buy' | 'sell'>('buy')

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }
    checkMobile()
    window.addEventListener('resize', checkMobile)
    return () => window.removeEventListener('resize', checkMobile)
  }, [])

  const handleTrade = () => {
    console.log(`${orderType.toUpperCase()} ${amount} FTSEB at ${price}`)
  }

  return (
    <div className={`grid gap-4 ${isMobile ? 'grid-cols-1' : 'grid-cols-1 lg:grid-cols-2'}`}>
      <Card className={`${isMobile ? 'w-full px-0' : 'lg:col-span-2'}`}>
        <CardHeader>
          <CardTitle>FTSEB/USDC Chart</CardTitle>
        </CardHeader>
        <CardContent className={isMobile ? 'px-1' : ''}>
          <TradingChart />
        </CardContent>
      </Card>
      <Card className={isMobile ? 'order-3' : 'order-3 lg:order-2'}>
        <CardHeader>
          <CardTitle>Order Book</CardTitle>
        </CardHeader>
        <CardContent>
          <OrderBook highlightSide={orderType} />
        </CardContent>
      </Card>
      <Card className={isMobile ? 'order-2' : 'order-2 lg:order-3'}>
        <CardHeader>
          <CardTitle>Place Order</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col space-y-4">
            <div className="flex space-x-2">
              <Button 
                onClick={() => setOrderType('buy')} 
                variant={orderType === 'buy' ? 'default' : 'outline'}
                className="flex-1"
              >
                Buy
              </Button>
              <Button 
                onClick={() => setOrderType('sell')} 
                variant={orderType === 'sell' ? 'default' : 'outline'}
                className="flex-1"
              >
                Sell
              </Button>
            </div>
            <Input
              type="number"
              placeholder="Amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
            <Input
              type="number"
              placeholder="Price"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
            />
            <Button onClick={handleTrade} className="w-full">
              Place {orderType.charAt(0).toUpperCase() + orderType.slice(1)} Order
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

