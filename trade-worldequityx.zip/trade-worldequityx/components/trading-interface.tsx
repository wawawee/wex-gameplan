"use client"

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { TradingChart } from "@/components/trading-chart"
import { OrderBook } from "@/components/order-book"

export function TradingInterface() {
  const [amount, setAmount] = useState('')
  const [price, setPrice] = useState('')

  const handleTrade = (action: 'buy' | 'sell') => {
    // Placeholder for trade logic
    console.log(`${action.toUpperCase()} ${amount} FTSEB at ${price}`)
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <Card>
        <CardHeader>
          <CardTitle>FTSEB/USDC Chart</CardTitle>
        </CardHeader>
        <CardContent>
          <TradingChart />
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Order Book</CardTitle>
        </CardHeader>
        <CardContent>
          <OrderBook />
        </CardContent>
      </Card>
      <Card className="md:col-span-2">
        <CardHeader>
          <CardTitle>Place Order</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col space-y-4">
            <Input
              type="number"
              placeholder="Amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
            <Input
              type="number"
              placeholder="Price"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
            />
            <div className="flex space-x-4">
              <Button onClick={() => handleTrade('buy')} className="flex-1">Buy</Button>
              <Button onClick={() => handleTrade('sell')} variant="secondary" className="flex-1">Sell</Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

