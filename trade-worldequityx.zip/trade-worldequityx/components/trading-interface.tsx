"use client"

import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { TradingChart } from "@/components/trading-chart"
import { OrderBook } from "@/components/order-book"

export function TradingInterface() {
  const [amount, setAmount] = useState('')
  const [price, setPrice] = useState('')
  const [isMobile, setIsMobile] = useState(false)

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }
    checkMobile()
    window.addEventListener('resize', checkMobile)
    return () => window.removeEventListener('resize', checkMobile)
  }, [])

  const handleTrade = (action: 'buy' | 'sell') => {
    // Placeholder for trade logic
    console.log(`${action.toUpperCase()} ${amount} FTSEB at ${price}`)
  }

  return (
    <div className={`grid gap-4 ${isMobile ? 'grid-cols-1' : 'grid-cols-1 lg:grid-cols-2'}`}>
      <Card className={isMobile ? '' : 'lg:col-span-2'}>
        <CardHeader>
          <CardTitle>FTSEB/USDC Chart</CardTitle>
        </CardHeader>
        <CardContent>
          <TradingChart />
        </CardContent>
      </Card>
      <Card className={isMobile ? 'order-3' : 'order-3 lg:order-2'}>
        <CardHeader>
          <CardTitle>Order Book</CardTitle>
        </CardHeader>
        <CardContent>
          <OrderBook />
        </CardContent>
      </Card>
      <Card className={isMobile ? 'order-2' : 'order-2 lg:order-3'}>
        <CardHeader>
          <CardTitle>Place Order</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col space-y-4">
            <Input
              type="number"
              placeholder="Amount"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
            <Input
              type="number"
              placeholder="Price"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
            />
            <div className="flex space-x-4">
              <Button onClick={() => handleTrade('buy')} className="flex-1">Buy</Button>
              <Button onClick={() => handleTrade('sell')} variant="secondary" className="flex-1">Sell</Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

