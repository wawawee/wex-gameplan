import Link from 'next/link'
import { ThemeSwitcher } from "@/components/theme-switcher"

export function Header() {
  return (
    <header className="flex items-center justify-between p-4 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <Link href="/" className="text-2xl font-bold">World Equity X</Link>
      <nav className="flex items-center space-x-4">
        <Link href="/">Trade</Link>
        <Link href="https://www.worldequityx.com/" target="_blank" rel="noopener noreferrer">About</Link>
        <ThemeSwitcher />
      </nav>
    </header>
  )
}

