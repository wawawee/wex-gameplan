"use client"

import { useState, useEffect } from "react"
import { Header } from "@/components/header"
import { TradingInterface } from "@/components/trading-interface"
import { PasswordProtection } from "@/components/password-protection"

export default function Home() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  
  useEffect(() => {
    // Check if user is already authenticated
    const authState = sessionStorage.getItem('isAuthenticated')
    if (authState === 'true') {
      setIsAuthenticated(true)
    }
  }, [])

  if (!isAuthenticated) {
    return <PasswordProtection onAuthenticate={setIsAuthenticated} />
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto py-8">
        <h1 className="text-4xl font-bold mb-8">Crypto for Stocks Trading Platform</h1>
        <TradingInterface />
      </main>
      <footer className="text-center py-4 mt-8">
        <p>&copy; 2023 WorldEquityX Trading Platform. All rights reserved.</p>
      </footer>
    </div>
  )
}

