import { Header } from "@/components/header"
import { TradingInterface } from "@/components/trading-interface"

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto py-8 px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl sm:text-4xl font-bold mb-8">World Equity X Trading Platform</h1>
        <TradingInterface />
      </main>
      <footer className="text-center py-4 mt-8">
        <p>&copy; 2023 WorldEquityX Trading Platform. All rights reserved.</p>
      </footer>
    </div>
  )
}

