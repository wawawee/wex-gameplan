import Header from "@/components/header";
import TradingInterface from "@/components/trading-interface";
import { useState } from "react";
import { ViewSwitcher } from "@/components/view-switcher";

function App() {
  const [currentView, setCurrentView] = useState("desktop");
  const containerClass = "container mx-auto px-4";

  return (
    <div className={`min-h-screen bg-background ${currentView === 'mobile' ? 'max-w-sm mx-auto' : ''}`}>
      <Header />
      <main className={`${containerClass} ${currentView === 'mobile' ? 'max-w-full' : ''}`}>
        <h1 className="text-3xl sm:text-4xl font-bold mb-8">World Equity X Trading Platform</h1>
        <TradingInterface />
      </main>
      <footer className="text-center py-4 mt-8">
        <p>&copy; 2023 WorldEquityX Trading Platform. All rights reserved.</p>
        <div className="mt-4">
          <ViewSwitcher currentView={currentView} onViewChange={setCurrentView} />
        </div>
      </footer>
    </div>
  );
}

export default App;

