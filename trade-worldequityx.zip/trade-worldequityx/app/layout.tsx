import './globals.css'
import { Inter } from 'next/font/google'
import { ThemeProvider } from "@/components/theme-provider"
import dynamic from 'next/dynamic'

const inter = Inter({ subsets: ['latin'] })

const DynamicWalletKitProvider = dynamic(
  () => import('@reown/walletkit').then((mod) => mod.WalletKitProvider),
  { ssr: false }
)

export const metadata = {
  title: 'Crypto for Stocks - WorldEquityX Trading Platform',
  description: 'Trade tokenized stocks with FTSEB tokens',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <DynamicWalletKitProvider
          projectId={process.env.NEXT_PUBLIC_REOWN_PROJECT_ID || ''}
          chains={['ethereum']}
        >
          <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
            {children}
          </ThemeProvider>
        </DynamicWalletKitProvider>
      </body>
    </html>
  )
}

